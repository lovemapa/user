const mongoose = require("mongoose");
const args = process.argv.slice(2);
const userSchema = require('./models/user')
const merchantSchema = require('./models/merchant')


mongoose.connect('mongodb://localhost:27017/bank', { useNewUrlParser: true, useCreateIndex: true, useUnifiedTopology: true }, (err, data) => {
    if (err) console.log(err)

});
mongoose.set('useFindAndModify', false);



if (args[1] == "user") {

    const user = {
        name: args[2],
        email: args[3],
        creditAmount: Number(args[4]),
    }
    creatUser(user)
}


if (args[1] == "merchant") {
    const newMerchant = {
        name: args[2],
        discount: Number(args[4].split('%')[0]),
    }
    createMerchant(newMerchant)

}


if (args[1] == "txn") {

    const user = args[2];
    const merchant = args[3];
    const amount = args[4];


    const promise = createTransaction(user, merchant, amount).then()
    promise.then(data => {
    })

}




if (args[0] == "report") {


    if (args[1] == "users-at-credit-limit") {

        reportLowCreditUser()
    }
    else if (args[1] == "discount") {


        const merchant = args[2]
        reportMerchantDiscount(merchant)

    }


}




async function creatUser(userBody) {
    const newUser = await userSchema(userBody)

    console.log(`${newUser.name}(${newUser.creditAmount})`);
    return newUser.save({})
}

async function createMerchant(merchantBody) {
    const newMerchant = await merchantSchema(merchantBody)

    console.log(`${newMerchant.name}(${newMerchant.discount}%)`);
    return newMerchant.save({})
}

async function createTransaction(userName, merchantName, amount) {
    const user = await userSchema.findOne({ name: userName })
    if (amount > user.creditAmount) {
        console.log("rejected! (reason: credit limit)");

    }

    else {
        const merchant = await merchantSchema.findOne({ name: merchantName })
        const newDiscountForUs = merchant.discountWeRecivedSoFar + (amount * merchant.discount) / 100

        await userSchema.findOneAndUpdate({ name: userName }, { $inc: { creditAmount: -amount } })
        await merchantSchema.findOneAndUpdate({ name: merchantName }, { $set: { discountWeRecivedSoFar: newDiscountForUs } })
        console.log("success!");
    }

}

async function reportLowCreditUser() {
    const lowCreditUsers = await userSchema.find({ creditAmount: { $lte: 0 } }, { name: 1 }).lean()
    lowCreditUsers.forEach(user => console.log(user.name))

}

async function reportMerchantDiscount(merchant) {
    const merchantProfile = await merchantSchema.findOne({ name: merchant })
    console.log(merchantProfile.discountWeRecivedSoFar);

}


