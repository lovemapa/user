const mongoose = require('mongoose');

const Schema = mongoose.Schema;


var merchantSchema = new Schema({
    name: String,
    discount: Number,
    discountWeRecivedSoFar: { type: Number, default: 0 }


}, { versionKey: false })

module.exports = mongoose.model('merchant', merchantSchema);