const mongoose = require('mongoose');

const Schema = mongoose.Schema;


var userSchema = new Schema({
    name: String,
    email: { type: String },
    creditAmount: Number


}, { versionKey: false })

module.exports = mongoose.model('user', userSchema);